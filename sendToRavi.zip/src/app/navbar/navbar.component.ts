import { Component } from '@angular/core';
import { faBars, faTimes } from '@fortawesome/free-solid-svg-icons';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss']
})
export class NavbarComponent {

  hamburGerIcon = faBars
  closeIcon = faTimes

  isOpen: boolean = false

  ShowMenu() {
    this.isOpen = true
  }

  closeMenu() {
    this.isOpen = false
  }
}
